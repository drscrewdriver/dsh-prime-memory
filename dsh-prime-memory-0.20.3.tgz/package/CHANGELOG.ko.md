# 변경 기록（한국어 changelog）

- [更新日志（中文）](./CHANGELOG.md)
- [Changelog (English)](./CHANGELOG.en.md)
- [日本語 changelog](./CHANGELOG.ja.md)
- [한국어 changelog](./CHANGELOG.ko.md)

> **호환성 참고**: 본 플러그인은 한국어 문서를 제공하지만, 공식 DSH의 `LocaleRuntime`이 등록하는 언어는 `zh` / `en`뿐입니다. `ko`를 선택하면 `locale "ko" is not registered` 오류가 납니다. DSH를 fork하여 `LOCALE_IDS`와 `LOCALES` 라벨을 갱신하고 재빌드하면 사용 가능해집니다.

이 파일은 **0.12.0** 릴리스 노트와 현재 **미출시** 변경 사항의 한국어판입니다. 전체 이력은 [CHANGELOG.md](./CHANGELOG.md)（中文）를 참조하세요.

## [0.19.0] — 2026-09-29

### 변경

- **DSH 0.2.0 대응（compat/0.2.0）**：peerDependencies와 engines.dsh(package.json + dsh.plugin.json)를 `>=0.2.0-rc.1 <0.2.1-0`로 일괄 갱신(단일 범위 치환. 0.1.7 라인은 compat/0.1.7 브랜치가 계속 지원)；dsh-* devDependencies 9건을 0.1.1-rc.2 → 0.2.0-rc.1로 재고정하고 type-only 의존성 `@deepseek-ai/dsh-compaction` 추가. 코드 측면에서 0.2.0 호스트 API 변화 대응：`agent/session-start` 이벤트를 `agent/created`로 통합(serial 계약에 맞춰 리스너를 async화)；Session 이벤트 읽기를 `session.events` → `session.snapshotEvents()`로 변경(호스트가 동기 전량 읽기를 폐기 예정. 폴백 체인 유지)；테스트 스텁 갱신(projection 커서 offset 시맨틱스).
- **릴리스 메타데이터**：버전 0.18.4 → 0.19.0；publishConfig.tag `dsh-0.1.7` → `dsh-0.2.0`；dsh.plugin.json version → `0.19.0-dsh0.2.0.1`.

## [0.18.4] — 2026-09-28

### 추가

- **크래시 복구(§A)**: 호스트가 턴 도중 크래시하면 해당 턴 대화는 메모리 버퍼와 함께 영구 유실되었습니다(resume 시 콜드스타트 보호가 전체 이력을 폐기). 이제 resume 시 호스트의 영속 이벤트 로그와 대조합니다: L0 기록 최대 turn을 워터마크로, 그 이후의 완전한 턴을 최대 2개까지 보수(크래시 고아 턴은 호스트가 `turn/end{reason:'interrupted'}`로 닫습니다 — 실기에서 98건 확인). 멱등성 = 워터마크 + 턴 단위 존재 검사. 호스트 읽기 서비스를 사용할 수 없으면 단계적 축소(`sessionQuery.readSession` → `sessionPersistence.readFrom` → 기존 동작 + 일회성 안내), 항상 fail-open으로 세션 시작을 막지 않습니다.
- **페이로드 마스킹(§C, `capture.redactSecrets`, 기본 활성)**: 캡처 쓰기 경계에서 8종의 시크릿(PEM 개인키 / Authorization 헤더 / Bearer·JWT / Cookie / 벤더 API 키 형태 / 이메일 / 9자리 이상 숫자(날짜 제외) / 고엔트로피 ID)을 `[REDACTED:<KIND>]` 타입 플레이스홀더로 치환 — L0 JSONL·L0 SQLite·증류 입력·수동 `memory_add`/`memory_import`를 단일 지점에서 커버. 안전값(`example` / `$VAR` / `${{…}}` 등)은 제외. 플레이스홀더는 카테고리 의미를 유지해 검색 가능. 주의: 활성화 후 L0 원문은 변경됩니다(재구축으로도 원문 복원 불가). `false`로 평문 복귀.
- **증류 프롬프트 내성 주입(§B)**: 6개 증류 프롬프트 파일(L1 추출 ×3 / L1 중복제거 ×3 / L2 씬 ×2 / L3 페르소나 ×2 / 그래프 투영 / 대조기) 모두에 "콘텐츠 경계(내성 주입)" 선언과 데이터 슬롯 경계를 추가 — 대화 원문·기존 기억 풀·씬 전문 등 임베디드 콘텐츠는 데이터이지 지시가 아닙니다. 판정 어휘와 출력 계약은 불변.

### 개선

- **주입 확인(§D)**: 리콜 주입은 반환 즉시 마크하지 않습니다. "pending → 로그 수신" 2단 방식 — 호스트가 주입 메시지를 실제로 세션 로그에 기록했을 때(`plugin:memory` 서명과 안정 id를 가진 `user/message`) `dedupe.mark` 합니다. 덮어쓰기·취소된 주입은 더 이상 기억을 오억제하지 않고(다음 턴 재주입 가능), 5분 수신 없으면 일반 마크로 축소(확인 경로 장애로 인한 중복제거 무효화 방지), 미확인 만료는 폐기.
- **압축 후 정밀 재주입(§E)**: `compaction/end`(error 없음) 후 해당 세션의 다음 턴에 한 번의 확장 리콜 실행 — 중복제거 억제를 건너뛰고(압축이 기존 주입을 컨텍스트에서 축출), 페르소나 즉시 재주입, 점유 원장 리셋. 사용 시 소비. 기존 compact/clear 전량 리셋은 폴백으로 유지되며 양 경로는 멱등.
- **구조화 트레이스(§F, `trace.*`)**: 리콜과 증류 이벤트를 일별 JSONL로 영속화(`<dataDir>/trace/`, 기본 보존 14일, 일별 5MB 상한에서 정지 + 마커). 리콜 이벤트는 query 지문(기본 metadata-only: 길이 + sha256, `trace.captureContent` 시 원문 ≤200자), 히트/주입 id, 스코어, 소요시간과 4가지 결과를 기록. 증류 이벤트는 runId·6값 결정 집계(`l1_receipts`와 동원으로 교차 감사 가능)·소요시간과 성패. 신규 엔드포인트 `dsh-memory/trace-tail`, 설정 페이지 "로그" 탭에 3개 데이터 소스 전환(시스템 로그 / 리콜 트레이스 / 증류 트레이스).

## [0.18.2] — 2026-09-27

### 수정

- **세션 포맷 v4 서명 대응(호스트 >= 0.1.7-rc.1)**: 기억 recall 주입 2곳(세션 간 recall `hooks/recall.ts`, 슬롯 상시 주입 `hooks/slot-recall.ts`)에서 v4 호스트가 거부하는 구형 서명 `source: { kind: 'plugin', plugin: 'memory', form: 'recall' }` 사용을 중단하고(`SessionFormatError`로 라운드 전체 실패——"기억 호출 시 오류"의 원인) producer-owned 서명 `{ kind: 'plugin:memory', form: 'recall' }`로 변경했습니다. `form`·내용·시점은 불변. 근거: `@deepseek-ai/dsh-session-format-v3-to-v4@0.1.7-rc.2`의 `source()`는 kind가 비어 있지 않고 `'plugin'`이 아닌지만 검증하며 수반 필드는 검증하지 않습니다.
- **읽기 측 이중 형상 호환**: recall 점유율 추정 서명 술어 `isOwnRecallSource`는 신규 서명과 v3 구형 행을 모두 받아들입니다——쓰기 측만 고치면 점유 패널의 "기억 recall 점유율"이 조용히 0이 됩니다. `MessageSourceMap`은 모듈 병합으로 `plugin:memory`를 등록(dsh-llm 0.1.7의 map은 `user|model|tool|'system-prompt'`으로 plugin catch-all 없음, producer별 merge-extensible).
- **tool-result v4 native 대응(N1)**: `store/evidence-source.ts`의取证 텍스트 읽기에 native 분기 추가(v4 일급 `role:'tool'` 메시지: content는 text/reasoning 블록 직접, `isError`는 message 최상위. 호스트 `assertBlock`은 구형 `tool-result` wrapper 블록을 강제 거부). 구형 블록 경로는 역사 호환으로 유지——미대응 시 v4에서取证 텍스트가 조용히 빈 값이 됩니다. `projection/slots.ts`의 isError 가드도 native화.

## [Unreleased]

### 추가

- **출처 앵커(R7) — 이제 기억을 세션 안의 실제 좌표까지 추적할 수 있습니다.** 지금까지 추적 체인은 끊겨 있었습니다: L1은 `source_message_ids`를 가지고 있지만 그것은 **L0 메시지 id**(`msg_<epoch_ms>_<hex>`)이고, L0 테이블에는 `turn`/`step` 컬럼이 없었습니다. 게다가 그 id 목록은 **검색 DB에 전혀 기록되지 않았습니다**(쓰기 측이 `metadata`만 저장하고 해당 필드는 조용히 버려졌습니다). 결과: **어떤 기억도 원문에서 위치를 찾을 수 없었습니다.**
  - `l0_conversations`에 `turn`/`step` 컬럼 추가(멱등 `ALTER TABLE`; 기존 행은 NULL 유지 = 앵커 없음, **추측으로 채우지 않습니다**)와 `(session_id, turn)` 인덱스.
  - 캡처 측에 `step/start` fold 추가: `user/message`는 커널 payload에 `step`이 없으므로 같은 턴의 `step/start`에서 유도합니다. `assistant/message`는 이벤트가 가진 `{turn, step}`을 사용합니다. **첫 `step/start` 이전 메시지는 `step`을 비워 둡니다** — 좌표가 없을 때 좌표를 만들어내지 않는 것이 기본입니다.
  - 앵커는 `metadata_json`의 예약 키 `dsh_source_anchors`에 저장됩니다(UI에는 `t12 s3`). 새 컬럼도, 디스크 계약 변경도 없습니다. **신규 저장 경로와 "병합/업데이트" 경로 모두** 앵커를 가집니다 — 한쪽만 있으면 병합 한 번에 좌표가 사라집니다.
  - 호스트 신규 API `MemoryDb.l0ByAnchor(sessionId, turn, step?)`: **좌표로**(시간순이 아니라) L0 메시지를 가져옵니다. 향후 "증거 리더"의 유일한 진입점입니다.
- **기록 패널이 출처 앵커를 표시**합니다(이전에는 항상 "-"였습니다).

- **기억 퇴장(소프트 삭제)과 정리 왕복: 삭제가 더 이상 데이터 손실이 아닙니다.** 기존의 "삭제"는 **물리 삭제**였고, 실수는 `records/*.jsonl` 사실 원본에서 손으로 건져내는 수밖에 없었습니다. 이제 두 단계이며 **되돌릴 수 있는 쪽이 기본**입니다.
  - **퇴장(소프트 삭제)**: 메인 테이블 행은 유지하고 `valid_to`를 닫은 뒤 대체 마커(`metadata` 예약 키 `dsh_superseded`: 시각 / 사유 / 판정 결과 / 충돌 페어 id)를 기록하고, `l1_fts`와 `l1_vec` 행만 제거합니다. **검색 측 SQL은 한 글자도 바꾸지 않았습니다**(쿼리 드리프트 0). 세 가지 퇴장 경로(판정 패배 / 중복 제거 대체 `update`·`merge` / 수동 삭제)는 **동일한 프리미티브를 공유**합니다.
  - **엔드포인트 33 → 38**: `records-retired` / `records-restore` / `cleanup-retired` / `snapshots-list` / `snapshot-restore`. 세 목록(`contract.ts` 맵 / `stats.ts`의 `MEMORY_ENDPOINTS` 허용 목록 / 디스패처 `case`)과 엔드포인트 총수 단언을 함께 갱신했습니다 — 하나라도 빠지면 해당 엔드포인트는 영구히 404가 되고, 클라이언트 `rpc`의 catch가 조용히 삼켜 패널 블록 전체가 사라집니다.
  - **`memory_delete`의 기본은 1건만 퇴장**(기존 3건)이며, 의미 매칭을 건너뛰는 `ids` **정확 경로**를 추가했습니다. 기존 의미 기반 top-N 일괄 삭제는 실측에서 **무관한 실제 기억 2건을 잘못 삭제**했습니다 — "정확히 지우기"는 유사도가 아니라 정확한 ID로 보장해야 합니다.
  - **물리 정리는 기본이 드라이런**(`dryRun` 생략 = `true`). 명시적으로 실행해도 먼저 **전체 라이브러리 스냅샷**을 쓰고 **내용 해시로 검증**하며, 불일치면 중단하고 한 건도 삭제하지 않습니다. 이를 우회 불가능하게 만들기 위해 `deleteL1Batch`를 **단일 호출자**(`exportThenPurge`)로 수렴시키고 소스 수준 가드 테스트로 고정했습니다.
  - **복귀 경로가 없었습니다.** `restoreL1Snapshot`은 **프로덕션 호출자가 전혀 없어서** "정리 전에 내보내기"가 절반만 성립했습니다(내보내기는 있는데 돌아오는 길이 없음). `snapshots-list` / `snapshot-restore`로 연결했습니다: 스냅샷 **디렉터리 이름만** 받고(경로와 `..`는 거부), 기본은 드라이런이며 `stillRetired`를 정직하게 보고합니다. 이 필드는 필수입니다 — 정리는 **이미 퇴장한** 기록만 지우고 스냅샷은 삭제 **전**에 찍히므로, 되찾을 수 있는 모든 기록에 퇴장 마커가 붙어 있습니다. **메인 테이블로 돌아온 것 ≠ 검색으로 돌아온 것**이며, 이를 말하지 않으면 "복구 완료"로 오해합니다. 완전한 한 번의 롤백은 `unretire: true`(기존 `restore`를 재사용, 새 쓰기 경로 없음)입니다.
  - **패널**: 기록 탭에 "퇴장됨(복구 가능)" 구획을 추가했습니다(기본 접힘, 펼칠 때만 조회). 삭제 확인 문구는 "복구 가능"으로 변경했습니다. **물리 정리는 의도적으로 패널 진입점을 만들지 않습니다** — 되돌릴 수 없는 동작은 RPC / 모델 표면에만 남깁니다.
- **§C 모순 동결: 동일 배치 내 모순도 이제 동결할 수 있습니다("모델이 유일하게 하는 말이 정확히 거부되는" 문제 수정).** 조사 결과 `validateConflictPair`의 세 번째 조건은 "상대방이 후보 풀의 기존 기록일 것"을 요구했지만, **동일 배치에서 생성된 새 기억의 id는 거기에 없습니다**(아직 저장되지 않았기 때문). 즉 가장 전형적인 "기계가 판단할 수 없는" 상황(한 배치의 모순된 두 새 기억)은 모델이 `conflict`를 올바르게 내도 **반드시 페어가 아니라고 판정되어 `store`로 폴백**했습니다. 증거: 모델 층에서는 7/7로 출력되지만 그 단계는 DB에 한 번도 도달하지 않았습니다(`conflict_pending`은 DB 생성 이래 0행, `l1_receipts`의 `conflict`는 `store 381 / merge 204 / update 172 / skip 7` 중 0건). 수정: `validateConflictPair`에 선택적 `batchIds` 추가(생략 = 기존 동작). 단 "정확히 한쪽이 본 기록"은 유지해 페어가 유일하도록 합니다. 또한 큐 만원 가드를 추가해 **패배자가 이번 배치의 새 기억이면 자동 종결하지 않습니다**(방금 추출된 산출물이 아무에게도 알려지지 않고 즉시 퇴장하는 것을 방지) — 단순히 대기시키지 않고 정상 저장합니다.

- **§C 모순 동결이 이제 "삼축 시간"을 이해합니다 — 내용은 모순이지만 시간상 선후가 있는 경우를 더 이상 일괄적으로 사람에게 넘기지 않습니다.** 기억 레코드에는 원래 서로 대체할 수 없는 세 개의 시간축(기록 시각 `createdAt/updatedAt`, 사실 유효 기간 `validFrom/validTo`, 지속성 `persistence`)이 있었지만, 모순 탐지는 기록 시각만 사용했습니다. 탐지기는 `conflict`를 판정할 때 유효 기간과 지속성을 볼 수 없어 "오래된 사실이 새 사실로 대체된" 경우를 사람이 판정할 대상으로 대기시키는 일이 흔했고, 판정 패널도 양쪽 본문만 보여주어 사람이 눈감고 판정해야 했습니다. 이번에 동결의 양 끝에 삼축을 연결했습니다:
  - **탐지 측**: 동결 **개방 시** 통합 후보 풀이 각 기억의 `valid_from_ms` / `valid_to_ms` / `persistence`를 탐지기에 전달하고, `conflict` 동작 조항에 "삼축 보조 판정"을 추가했습니다 — 내용이 모순되면 먼저 유효 기간과 지속성을 비교하고, 한쪽이 만료되었거나 명백히 더 늦으면 `update` / `merge`를 우선합니다. **세 키와 조항 모두 `conflictFreeze`로 게이트됩니다**: 폐쇄 상태의 user prompt는 변경 전과 **바이트 단위로 동일**합니다(아래 "수정" 및 [ADR-0012](./docs/adr/0012-conflict-3axis-advisory-time-axes.md) 참조).
  - **판정 측**: `ConflictPairView`에 선택적 `winner_*` / `loser_*` 삼축 필드를 추가했습니다(하위 호환). 대기 목록과 그 렌더링은 각 쌍에 "유효 기간 시작/종료, 지속성" 비교를 덧붙여 어느 쪽이 더 새로운지, 어느 쪽이 만료되었는지 한눈에 보이게 합니다.
  - 기계는 **여전히 자동 판정하지 않습니다**: 삼축은 보조 사실일 뿐이며 최종 결론은 여전히 사람(또는 안전 밸브의 타임아웃/큐 만원 자동 종결)이 씁니다 — `ConflictResolution` 값은 변하지 않습니다.

### 수정

- **폐쇄 상태 prompt에 삼축 필드가 조용히 추가되어 있었습니다(동결 OFF = 기본 배포에 영향).** 첫 버전은 `valid_from_ms` / `valid_to_ms` / `persistence`를 후보 풀에 **무조건** 주입했지만, 이 LLM 호출은 system prompt에만 스위치를 읽었습니다. 그래서 `conflictFreeze=false`(배포 기본값)에서는 모델이 후보마다 3개의 키를 더 보았고, **이를 설명하는 조항이 전혀 없었습니다** — 토큰이 늘고 입력이 바뀌었습니다. 세 키를 `conflictFreeze`로 게이트하여 폐쇄 상태의 user prompt가 변경 전과 **바이트 단위로 동일**해졌으며, 판정 기준도 "특정 부분 문자열을 포함하지 않음"에서 **sha1 golden 앵커 + 반증 검증**(게이트를 깨면 해당 케이스가 빨간색)으로 상향했습니다.
- **스위치는 분명히 켜져 있는데 패널은 "모순 동결 미개방"이라고 표시했습니다.** `conflicts` / `conflict-resolve` 엔드포인트는 **배포 시점의 정적 설정** `cfg.conflictFreeze.enabled`를 읽었지만, 패널은 **런타임 설정**(live)에 기록했습니다. 배포 기본값은 항상 `false`이므로, 스위치가 켜지고 `settings.yaml`에 `true`가 저장되어도 미개방으로 표시됩니다. `effectiveCfg(cfg, live)` 경로로 변경해 중복 제거 파이프라인과 동일한 해석으로 통일했습니다 — 진실의 원천은 **하나**이며, 읽는 쪽과 쓰는 쪽이 같은 상태를 봐야 합니다.
- **`dsh-memory/embedding-reindex`는 선언되었지만 영구히 404였습니다.** 계약에는 있으나 `MEMORY_ENDPOINTS` 허용 목록과 디스패처 `case` 양쪽에 없었고, `startReindex()`는 **죽은 코드**였습니다(설정의 "벡터 인덱스" 블록에 "시작"이 없고 "취소"만 있던 이유). 허용 목록 + `case` + 테스트를 추가했습니다.
- **`UiRecord.sourceMessageIds`는 죽은 필드였습니다.** `l1_records`에 **존재하지 않는 컬럼**을 읽어 항상 `[]`가 되었고, 패널의 출처 행은 **한 번도 렌더링되지 않았습니다**. 실제 데이터를 읽는 `sourceAnchors`로 교체했습니다.

## [0.12.0] — 2026-09-17

### 추가

- **벡터 인덱스 수동 재구축(`dsh-memory/embedding-reindex` 엔드포인트 + 설정 화면의 "벡터 인덱스" 블록)**. 지금까지 재구축 계기는 시작 시의 `db.init` 변경 감지 체인과, 누락 벡터를 채우는 주기적 backfill 두 가지뿐이었고 **수동 진입점이 없었습니다**. 설정 화면에 보이는 것은 "취소"뿐(그것도 재구축이 실행 중일 때만)이었고, "시작"도, 얼마나 임베딩되었고 얼마나 남았는지도 알 수 없었습니다.
  - **엔드포인트 면 31 → 32**. `EmbeddingReindexStartResponse`(`{accepted:true}`) 신설. **접수 후 즉시 반환하며 진행률은 여기서 반환하지 않습니다** — 클라이언트는 기존대로 `embedding-state-get`의 `reindex` 필드를 폴링합니다. 진행률 어휘가 두 벌이면 언젠가 서로 어긋나므로 의도적으로 하나만 유지합니다. 네 곳(`contract.ts` 매핑 / `MEMORY_ENDPOINTS` 허용 목록 / 디스패처 `case` / 엔드포인트 총수 단언)을 함께 갱신했습니다. **하나라도 빠지면 해당 엔드포인트는 영구 404**가 되고, 클라이언트 `rpc`의 catch가 이를 조용히 삼키므로 패널 전체가 사라집니다.
  - **`EmbeddingStateView`에 `vectors` 추가**: L1 / L0 각각의 `embedded` / `total` / `missing` / `skipped`. "X / Y 임베딩됨"이 여기서 나옵니다. db 계층의 **`-1` 센티넬은 그대로 통과**시킵니다 — "벡터 기능을 쓸 수 없음"과 "하나도 임베딩하지 않음"은 UI에서 서로 다른 문장이어야 하며, 하나의 숫자로 합치면 절대 반응하지 않는 버튼을 사용자에게 계속 누르게 만듭니다.

### 수정

- **"접수했지만 실제로는 돌지 않는" 재구축 요청을 거부**. `L1Store.reindex` / `L0Store.reindex`의 첫 줄은 벡터 기능이 준비되지 않았을 때 **조용히 `0/0/0`으로 단락**됩니다. 진입점에 게이트가 없으면 UI는 "재구축 완료, 미처리 0건"을 표시하지만 실제로는 **한 번도 시작하지 않았습니다**. 이 함정은 `src/index.ts:240`에 이미 주석이 있었으나 시작 체인만을 대상으로 했고, 수동 진입점은 새로운 구멍이었습니다. `startReindex()`는 다섯 개의 게이트를 모두 앞당기고 각각 **행동 가능한** 문구를 부여합니다: 언로드됨 / 재구축 진행 중 / 소스 전환이 잠금 보유 / **임베딩 소스 꺼짐**(`currentInfo` 비어 있음) / **서비스 미준비**. ("먼저 활성화하세요"와 "조금 기다리세요"는 서로 다른 지시이며 하나로 합쳐서는 안 됩니다.) 이를 위해 두 스토어에 `vectorsReady()` 접근자를 추가했습니다 — `helper`가 private이라 외부에서 물어볼 방법이 없었기 때문입니다.
- **`embedding-subsystem.test.ts`의 `db` 스텁이 불완전**. `swapProvider` / `markEmbeddingSynced` 두 개만 가지고 있었고 `as never`로 타입 검사를 우회했기에 누락이 드러나지 않았습니다. `snapshot()`이 벡터 개수를 포함하기 시작하자 즉시 죽습니다(`getVecSkipSet is not a function`). **`vectorCounts`를 방어적으로 만드는 대신 스텁을 보완**했습니다: 타입 시그니처는 완전한 `MemoryDb`를 선언하고 있으며, 누락된 메서드를 삼키는 것은 실제 배선 오류까지 함께 숨기는 일이기 때문입니다.

### 테스트

- 신규 5건: 꺼짐 상태 거부 / 미준비 거부 / 접수 후 L1+L0 구동 및 동시 두 번째 즉시 거부 / 언로드 후 거부 / `snapshot` 개수 기준. **모든 거부 경로에서 "예외를 던진다"와 "하위가 한 번도 호출되지 않는다"를 함께 단언**합니다 — 예외만 단언하면 "먼저 하위를 호출하고 나서 던지는" 구현도 통과합니다.
- **반증**: 준비 가드를 일시적으로 제거하면 `向量能力未就绪 → 拒绝`가 실제로 빨간색이 되고(`expected [Function] to throw an error`), 되돌리면 다시 초록색이 됩니다.
- 전체 **39 파일 / 403 케이스** 통과. `typecheck`(tsconfig 3종), `build`, `smoke` 모두 초록.

## [미출시]

### 추가

- **§E 스토리지 스코프 `scope`(가시 범위, `family`와 직교)**. 지금까지 모든 프로젝트가 하나의 기억 저장소를 공유하여 프로젝트 A에서 증류한 `work` 패밀리 기억이 프로젝트 B 대화에서도 검색되었습니다. 새 `scope` 설정(`global` 기본 / `workspace`)을 추가하고 기존 `family`와 **직교**시킵니다——`family`는 "이것이 어떤 내용인가", `scope`는 "어디까지 보여야 하는가"에 답합니다. "`workspace` 모드에서 `work` 패밀리를 워크스페이스 단위로 격리하고 `chat` 패밀리는 기본적으로 전역 유지"는 **기본값이며 유도 규칙이 아닙니다**(개인 기억은 프로젝트를 넘어야 하고, 오염 면은 프로젝트 사이에 있습니다).
  - **제로 드리프트는 비교가 아니라 구조로 보장**: `cfg.scope`가 `workspace`가 아니면 공용 `scopeFilterOf`가 항상 `undefined`(= 필터 없음)를 반환하므로 어떤 호출 지점도 실수로 워크스페이스 식별자를 넘길 수 없습니다. 기존 배포(키 미지정)의 동작은 **바이트 단위로 동일**합니다.
  - **격리는 패밀리 격리와 같은 층**에 놓입니다: 검색 출구뿐 아니라 **중복 제거 후보 회수**도 필터합니다. 후보 풀이 다음 중복 제거 판단을 결정하므로 여기가 워크스페이스를 넘으면 "프로젝트 B에서는 보이지 않는데 이미 프로젝트 A 기억의 향방을 결정한" 기억이 생겨 격리하지 않는 것보다 나쁩니다([`ADR-0008`](./docs/adr/0008-storage-scope-vs-family.md)). 그래프 경로는 **출처 레코드**의 귀속으로 같은 층에서 필터하고, 쓰기 경로(추출 파이프라인 / `memory_add` / `memory_import`)는 동일한 `resolveRecordScope`를 공유합니다.
  - **워크스페이스 식별자는 canonical cwd를 쓰고 호스트 `dsh-workspace`의 `WorkspaceId`(uuid)는 쓰지 않습니다**: §A의 `parentSession`과 같은 header 경로로 동기 획득되며, `inject`를 선언하면 해당 서비스가 없는 호스트에서 트리 전체 로드가 실패하고, 호스트 자신의 구성원 판정도 "session header의 canonical cwd == workspace path"이며, uuid는 "등록된 워크스페이스"를 요구하므로 미등록 디렉터리에서는 격리가 조용히 무효화됩니다. 알려진 경계: **심볼릭 링크는 해석하지 않습니다**——결과는 과잉 격리(안전한 방향)이며 누출이 아닙니다([`ADR-0009`](./docs/adr/0009-workspace-identity-source.md)).
  - **마이그레이션은 귀속만 표시하고 옮기지도 삭제하지도 않습니다**: `l1_records` / `l1_fts`에 `scope` + `workspace_id`를 추가하고 기존 데이터는 `ALTER` 기본값으로 `global`로 분류됩니다——행 수, id, content, created_time이 바이트 단위로 불변입니다.
  - **실행 중 발견한 실제 결함 2건**: ① FTS 재구축 재주입이 scope를 빠뜨리면 **격리가 조용히 지워집니다**(컬럼 수 불일치가 행별 `catch`에 삼켜져 `count=0`의 빈 인덱스가 됩니다). ② 쓰기 측의 **형태 정규화 누락**으로 "기억은 써졌는데 다시는 검색할 수 없는" 상태가 생깁니다(검색 측은 정규화된 소문자 경로를 넘기고 저장 측은 호출자의 대문자 문자열을 그대로 보관하여 문자열 일치가 반드시 어긋납니다). 둘 다 엔드투엔드 테스트와 변이 프로브가 잡아냈습니다.
- **§F 그래프 노드 벡터 열 `graph_node_vec`(저장과 강등의 토대)**. 그래프는 기존에 어휘 가중 점수만 있어 의미상 동등하지만 자구가 다른 실체("云深处"와 "DeepRobotics")를 상호 해소할 수 없었습니다. `l1_vec`과 **동일 패턴**의 vec0 가상 테이블을 추가하고(동일한 인코딩, 동일한 `float[N] distance_metric=cosine` 선언) 차원은 **기존 능력 탐지 결과를 재사용**하여 두 번째 탐지를 만들지 않습니다.
  - **강등은 내부 `try/catch`에서 소화**: vec0가 없으면 테이블 생성이 예외를 던지고, 그것이 `GraphStore.init`의 바깥 catch에 도달하면 그래프는 "벡터 경로 사용 불가"에서 "**그래프 영역 전체 사용 불가**"로 강등되어 어휘 검색·투영·재정을 끌고 갑니다([`ADR-0011`](./docs/adr/0011-graph-node-vector-storage-and-degradation.md)).
  - **이번 웨이브는 문만 놓았고 생산자와 소비자는 미연결**: 투영 파이프라인은 아직 임베딩을 계산하지 않습니다. 미완료로 기록합니다——§F의 출발점이며 종착점이 아닙니다.

- **§B L1 결정 증거 체인(추적 가능성 기반)**. 모든 L1 레코드는 중복 제거 판단의 **결과**지만, 판단 자체는 흔적을 남기지 않았습니다(결과는 보이지만 무엇에 근거했는지는 보이지 않음). 새 테이블 `l1_receipts`가 판단마다 증거를 남깁니다(`run_id` / `record_id` / `kind` / **후보 풀의 순서 있는 sha256 다이제스트** / `decided_at`). 새 도구 **`memory_receipts`** 와 RPC 엔드포인트 **`dsh-memory/receipts`** 로 레코드 단위·배치 단위 **2차원 소급**이 가능합니다. 증거는 이벤트 **이전**에 존재해야 합니다——입력 스냅샷은 **사후에 채워 넣을 수 없기** 때문입니다([ADR-0006](./docs/adr/0006-l1-decision-receipts.md)).
  - 보존 정책은 **run 수** 기준(`RECEIPTS_MAX_RUNS = 1000`)——시간 창으로는 행 수의 상한을 줄 수 없습니다. 또한 트리밍은 **run 단위이며 행 단위가 아닙니다**(행 단위로 자르면 "반쪽 배치"가 생겨 완전해 보이지만 실제로는 누락된 결론을 내놓습니다——"찾을 수 없음"보다 해롭습니다).
  - 레드라인: 트리밍은 **`l1_receipts`만 건드리고 `l1_records`는 절대 건드리지 않습니다**.
  - 실패 격리: 증거는 측면 인프라이므로 쓰기 실패는 `warn`만 남기고 **L1 증류를 절대 중단하지 않습니다**.

- **§C 모순 동결(선택, 기본 꺼짐)**. 기존 중복 제거 **결정 어휘**는 `store` / `update` / `merge` / `skip`뿐이어서, "충돌 감지기"가 모순을 감지해도 **LLM이 직접 재정해 기록**했고 **"멈추고 사람에게 묻는" 선택지가 없었습니다**. `conflictFreeze.enabled`를 켜면 어휘에 `conflict`가 추가되어, 양쪽 다 맞아 보여 기계가 판단할 수 없을 때 그 쌍을 `conflict_pending`에 **대기**시킵니다——**새 기억은 평소대로 저장되고 양쪽 내용 모두 바뀌지 않습니다**. 재정은 새 도구 **`memory_resolve_conflict`**(RPC: `dsh-memory/conflict-resolve`)로 하며 결론은 `winner` / `loser` / `both`입니다.
  - **동결은 "쓰기를 막는 것"이 아니라 "자동 재정하지 않는 것"**——전자는 정보를 잃어, 해결하려던 문제보다 나빠집니다.
  - **안전밸브**: `maxPending`(큐 상한) / `timeoutDays`(타임아웃 강등). 의미는 "**새것을 받지 않는다**"이지 "오래된 것을 조용히 지운다"가 아닙니다——자동 결착된 쌍도 **큐의 행으로 남고** `resolution = auto`로 사람의 결론과 구분됩니다.
  - **그래프 측**: 동결된 레코드를 소스로 가진 노드는 `disputed`가 됩니다(기존 상태. 검색 후보에는 남으므로 "평소대로 회수되지만 상태가 보이는" 중간 상태). 이 부여는 **파생 동기화**이며 단방향 플래그가 아닙니다——재정은 분쟁을 **취소**하므로, 단방향이면 해결된 노드가 영원히 `disputed`로 남아 **파생 그래프가 사실과 어긋납니다**.
  - **제로 드리프트**: 꺼져 있을 때 중복 제거 프롬프트는 변경 전과 **바이트 단위로 동일**합니다. 이는 **구조적** 보증(꺼진 경로는 base 상수를 그대로 반환)이며 수동 비교가 아닙니다([ADR-0010](./docs/adr/0010-conflict-freeze-default-off-and-timeout.md)).

### 변경

- **새 설정** `conflictFreeze.enabled`(기본 꺼짐) / `conflictFreeze.maxPending`(100) / `conflictFreeze.timeoutDays`(30, `0` = 타임아웃 강등 없음). **새 엔드포인트** `dsh-memory/receipts`와 `dsh-memory/conflict-resolve`(엔드포인트 면 26 → 28).
- **`L1ReceiptKind`에 `conflict` 추가**. 동작 어휘를 확장할 때는 **그 어휘를 소비하는 모든 지점**(증거 정규화·통계 로그·렌더 문구·schema 설명)을 함께 확인해야 합니다——실행 중 실측: 등록 누락이 있으면 "모델이 **명확히** 판단 불가라고 말한" 것이 `skip_missing`(= "모델이 **답하지 않음**")으로 기록되고, §C의 감사 가능성은 **전적으로** 증거 체인에 의존하므로 감사 결론이 사실과 **정반대**가 됩니다.

### 수정

- **미인식 액션이 폴백 분기에 조용히 흡수됨**. `pipeline/l1.ts`의 적용 루프는 `store` / `skip`만 명시 분기하고 **나머지 액션은 모두 update/merge 분기로 떨어집니다**. conflict 판단은 설계상 `target_ids`가 없어 `targets=[]`가 되고, "0건을 교체한" 병합 산물로 추가되어 `version`이 **1**로 계산되었습니다. **오류도 없고 데이터 손실도 없으며 흔적은 version 숫자 하나뿐**——즉 conflict가 조용히 merge/update로 강등되고 있었고, 이는 §C가 바로 제거하려던 동작입니다. **수정**: 명시적 `conflict` 분기를 추가하고, 검증 실패 또는 스위치 꺼짐일 때는 **`store`로 폴백**하며 폴백 분기로는 절대 떨어지지 않습니다.
- **엔드포인트 게이트가 손으로 베낀 목록이었음**. `tests/contract-keys.test.ts`는 실제 등록표를 import하지 않고 복제했기 때문에 두 단언이 복제본 자체와만 일치했습니다. §B가 `receipts`를 추가해 실제 등록표가 27이 되어도 복제본은 26이었고 개수 단언도 `toBe(26)` 그대로여서——**계속 초록**이었습니다. 이번에 `conflict-resolve`를 추가해도 **여전히 초록**이었습니다. **수정**: 로컬 목록이 `MEMORY_ENDPOINTS`와 항목 단위로 일치함을 단언합니다.

## [0.11.0] — 2026-09-13

### 호환성（DSH 플러그인 프레임워크 문서 적합화）

- **settings 등록 크로스 버전 대응（0.1.1-rc.2 ~ 0.1.5-rc.2）**. 기존 `src/settings.ts`는 `@deepseek-ai/dsh-settings`에서 `settingsNamespace()`를 **값 임포트**했는데, v0.1.3+에서는 이 익스포트가 제거되어 새 호스트에서는 모듈 로드 시점에 `Failed to load plugins`이 발생해 플러그인 트리 전체가 함께 깨집니다. 현재는:
  - 네임스페이스는 문자열 리터럴 `'dsh-memory'`（브라우저 측은 원시 문자열만 읽으므로 신구 호스트에서 동등）. 타입 임포트만 남기고（컴파일 시 소거, 로드 리스크 없음）.
  - 등록은 3분기 런타임 분기: 우선 `settings.register()`（모든 대상 버전에 존재, get/watch/update 스코프를 반환하며 라이브 토글과 UI 쓰기가 모두 이를 경유）; 폴백은 `settings.installSection()` 브리지（v0.1.2+ 서비스 표면, `register`이 없을 때만. 런타임 쓰기는 비즈니스 오류로 명시 거부）; 둘 다 없으면 상시 온으로 강등——"settings 장애가 호스트를 꺾지 않는다"는 원칙은 불변.
  - `SettingsScope`는 로컬 구조 타입으로 변경, 패키지 수준 타입 익스포트에 의존하지 않음.
- **`dsh.plugin.json` 추가**（DSH 발견 매니페스트: id / `engines.dsh` `>=0.1.1-rc.2 <0.2.0-0` / components는 `dist/` 산출물 지정）. `dsh-plugin-template` 표준 파일 구조 준수.
- **`@deepseek-ai/dsh-*` peerDependencies를 optional로 전환하고 범위 확대**（`^0.1.1-rc.2 || ^0.1.2-rc.1 || ^0.1.3-rc.1 || ^0.1.5-rc.2`）. `@deepseek-ai/cordis`는 필수 유지——awesome-dsh-plugin 제출 요건 B.3 준수.
- **`screenshots.json` 추가**（`assets/img/` 참조 8장）, 제출 카드에 표시 가능.

### 변경

- `package.json` 버전을 0.11.0으로 상향. npm `files`에 `dsh.plugin.json` 추가（`screenshots.json`은 awesome-dsh-plugin 탐색 규약에 따라 git 리포지토리 전용, npm 패키지에는 미포함）.

### 실측 대기

- v0.1.5-rc.2에서의 `conversation.input.left` / `settings.section` 슬롯과 Session V3의 `session.surface.nodes` 시맨틱스（occupancy 추정）는 미검증. README의 호환성 매트릭스 참조.
